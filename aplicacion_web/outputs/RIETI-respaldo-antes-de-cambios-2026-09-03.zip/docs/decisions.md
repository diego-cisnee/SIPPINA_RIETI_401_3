# Registro de decisiones y aprobaciones

## Bloque 0 — Inicio del proyecto

- Objetivo: crear un dashboard web navegable como prototipo.
- Tecnología actual: HTML y CSS sin dependencias externas.
- Datos: ficticios durante la fase de prototipo.
- Integraciones futuras: JavaScript, API, base de datos y app móvil.
- Método: revisión y aprobación del usuario al terminar cada bloque.
- Estado: aprobado por continuación al Bloque 1.

## Bloque 1 — Login y dashboard

- Referencias: capturas proporcionadas por el usuario.
- Login: correo electrónico, contraseña y acceso simulado al dashboard.
- Dashboard: métricas, gráfico de estados, mapa de calor temporal y reportes recientes.
- Interacción habilitada: acceso desde el login, “Ver todos” y apertura de un reporte.
- Alcance diferido: pantallas de todos los reportes y del reporte individual.
- Estado: aprobado con ajustes solicitados.

## Ajuste 1.1 — Acciones del login

- El icono de ojo permite mostrar y ocultar la contraseña.
- “¿Olvidaste tu contraseña?” abre un aviso temporal sin abandonar el prototipo.
- La futura página de recuperación todavía no se implementa.
- Estado: aprobado por continuación al Bloque 2.

## Bloque 2 — Gestión de reportes

- Acceso habilitado desde el menú lateral y “Ver todos” del dashboard.
- Filtros disponibles: municipio, estado, prioridad, fecha inicial y fecha final.
- Los filtros trabajan temporalmente con los datos ficticios de la tabla.
- Cada renglón completo abre el aviso del futuro detalle del reporte.
- El menú de tres puntos despliega “Cambiar estado”, “Asignar autoridad” y “Eliminar”.
- Las tres acciones permanecen sin funcionalidad hasta su siguiente bloque.
- “Actualizar” y “Exportar CSV” muestran avisos temporales.
- Estado: aprobado con mejoras solicitadas.

## Ajuste 2.1 — Menús y filas del dashboard

- Los menús de tres puntos se cierran al hacer clic fuera o presionar Escape.
- Los renglones del dashboard abren el aviso del reporte desde cualquier zona no interactiva.
- El dashboard incorpora las mismas opciones: cambiar estado, asignar autoridad y eliminar.
- Las opciones siguen sin ejecutar cambios en los datos.
- Estado: aprobado por continuación al Bloque 3.

## Bloque 3 — Cambiar estado y asignar autoridad

- Ambos formularios se abren desde los tres puntos en dashboard y gestión.
- Estado: muestra folio, estado y prioridad actuales; permite seleccionar nuevos valores y añadir comentarios.
- Se corrigió la etiqueta duplicada de la referencia a “Nueva prioridad”.
- Autoridad: solo incluye “Por definir”, sin catálogo real.
- Cancelar descarta los valores escritos; Escape también cierra el formulario.
- Actualizar muestra una confirmación con el resumen de la solicitud simulada.
- No se guardan datos, no se modifica la tabla ni se contacta una API.
- Eliminar continúa desactivado.
- Verificación: prueba local del controlador, validación y confirmación superada.
- Estado: aprobado por continuación al Bloque 4.

## Bloque 4 — Seguimiento de reporte

- Acceso real desde cada renglón del dashboard y gestión, con folio y origen en la URL.
- La ruta y Volver distinguen Dashboard de Gestión de reportes.
- Resumen: estado, prioridad, fecha de reporte y última actualización.
- Contenido: denunciante, ubicación, coordenadas, detalles del caso, evidencias, administrador, autoridad y comentarios.
- Los folios y datos principales coinciden con sus renglones; los datos adicionales son ficticios.
- Ver en mapa y descargar adjuntos muestran avisos sin servicios externos ni descargas.
- Acciones rápidas reutilizan los formularios de estado y autoridad y su confirmación simulada.
- Eliminar permanece desactivado; Imprimir abre el diálogo de impresión del navegador.
- No se guardan cambios en una base de datos.
- Verificación local: 11 folios, ambos orígenes, folios inválidos y formularios compartidos.
- Estado: aprobado por continuación al Bloque 5.

## Bloque 5 — Estadísticas / Reportes

- Primera pestaña implementada; Gráficos y Rendimiento permanecen pendientes.
- Columnas: folio, denunciante, municipio, tipo de trabajo, observaciones, autoridad, estatus, prioridad y fecha.
- Textos largos con elipsis visuales, información completa en seguimiento.
- Catálogo provisional: venta ambulante, limpieza de parabrisas, comercio, trabajo agrícola, construcción y trabajo doméstico.
- Catálogo compartido con el seguimiento para evitar valores distintos del mismo reporte.
- Filtros por municipio, tipo de trabajo y fechas; métricas calculadas sobre los 11 registros ficticios disponibles.
- Autoridades sin asignar hasta definir el catálogo real.
- Menú de acciones compartido; Actualizar y Exportar CSV conservan avisos temporales.
- Acceso al seguimiento con ruta de regreso a Estadísticas.
- Verificación local de catálogo, columnas, filtros, métricas, origen y formularios.
- Estado: implementado, pendiente de aprobación.

### Ajuste — Orden de columnas de Estadísticas

- Orden solicitado: folio, tipo de trabajo, observaciones, municipio, autoridad, estatus, prioridad, fecha y denunciante.
- El menú de tres puntos permanece al extremo derecho; los demás apartados y comportamientos no cambian.
- Estado: ajuste implementado, pendiente de aprobación.

## Bloque 6 — Estadísticas / Gráficos

- El bloque de Reportes y su orden de columnas quedan aprobados por continuación.
- Referencias: capturas de Gráficos compartidas por el usuario.
- Cuatro gráficas: distribución por estatus, mapa de concentración provisional, reportes por municipio y tendencia mensual.
- Todas permiten abrir un resumen escrito mediante clic, Enter o espacio, con aviso visible de interacción.
- Los resúmenes incluyen cantidades, porcentajes cuando corresponden y contexto de los filtros aplicados.
- Los cálculos reutilizan los 11 reportes ficticios del catálogo compartido, sin inventar totales independientes.
- Filtros por municipio, tipo de trabajo y fechas; aplicación al cambiar un valor o presionar buscar. Limpiar restaura la muestra completa.
- Cualquier filtro activo oculta Reportes por municipio y muestra una explicación. Sin filtros, reaparece.
- Fechas inclusivas, validación de rango y estados sin resultados.
- El mapa muestra concentración sobre coordenadas de muestra; no incorpora límites municipales oficiales. Su cartografía real queda pendiente.
- Gráficas SVG sin dependencias; puntos de integración futura comentados en JavaScript y HTML.
- Actualizar y Exportar mantienen avisos; Rendimiento continúa pendiente.
- Verificación local: cálculos, filtros combinados, resumen, cierre/foco, rangos inválidos, resultados vacíos y regresiones anteriores.
- Estado: implementado, pendiente de aprobación. No se publica ni se conecta a servicios externos en este bloque.

### Ajuste 6.1 — Texto de gráficas sin negritas

- Títulos y textos de las gráficas con peso normal.
- Se elimina el contorno heredado de los iconos en las etiquetas SVG, que engrosaba números y letras.
- No cambian los datos, filtros, resúmenes ni el resto de la interfaz.

### Ajuste 6.2 — Restaurar formato exterior

- Los títulos recuperan la negrita original y se retira el cambio general de peso del contenedor.
- Las gráficas conservan sus etiquetas sin negritas ni contorno; no se altera su contenido ni funcionamiento.

## Bloque 7 — Estadísticas / Rendimiento

- Gráficos y sus ajustes quedan aprobados por continuación. No se modifican sus gráficas ni estilos; solo se habilita la pestaña Rendimiento.
- Nueva vista según la referencia: autoridad, municipio, total asignados, pendientes, en proceso, finalizados, tiempo promedio y eficiencia.
- Una autoridad ficticia por municipio, con nueve municipios de muestra. El catálogo de asignación de reportes permanece sin cambios.
- Datos agregados independientes para esta pantalla, identificados como ficticios. No representan asignaciones de los 11 reportes del catálogo anterior.
- Filtro automático desde la primera letra, con coincidencias parciales y tolerancia a acentos, mayúsculas y espacios.
- Autocompletado con sugerencias seleccionables por clic o flechas y Enter; Escape, Tab y clic exterior cierran la lista. Limpiar restaura todas las autoridades.
- Tarjetas y tabla se recalculan sobre las coincidencias visibles.
- Fórmula provisional de eficiencia: finalizados / asignados × 100. Promedio en días ponderado por casos finalizados. Ambos criterios quedan visibles para aprobación.
- Los totales suman pendientes, en proceso y finalizados. Sin asignados o sin finalizados se muestra “—” donde no puede calcularse una tasa o promedio.
- No se incluyen variaciones contra un período anterior porque la muestra no contiene ese histórico.
- Actualizar y Exportar conservan avisos, sin operaciones externas.
- Verificación: unicidad municipal, cálculos, búsqueda parcial, acentos, autocompletado, teclado, cierres, cero, vacío y regresiones.
- Estado: implementado, pendiente de aprobación; sin conexiones ni publicación externa.
