package tec.spn.rieti.viewmodel
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class StatItem(
    val value: String,
    val label: String
)

data class MainUiState(
    val stats: List<StatItem> = emptyList()
)

class MainViewModel : ViewModel() {

    //Placeholder para API
    private val _uiState = MutableStateFlow(
        MainUiState(
            stats = listOf(
                StatItem("24/7", "Disponibilidad"),
                StatItem("14", "Municipios cubiertos"),
                StatItem("100%", "Confidencial"),
                StatItem("3", "Canales de comunicación")
            )
        )
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()
}

