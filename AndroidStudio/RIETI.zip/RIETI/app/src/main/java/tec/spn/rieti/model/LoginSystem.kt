package tec.spn.rieti.model

class LoginSystem {

    fun verifyLogin(user: String, password: String): Boolean {
        //sustituir con llamado lambda cuando este backend
        return user == "user" && password == "pwd"

        //val authResponse = lambda(user,password)
        //return authResponse

    }


}