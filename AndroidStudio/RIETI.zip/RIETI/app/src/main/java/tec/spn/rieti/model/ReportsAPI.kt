package tec.spn.rieti.model

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Path

data class ReportResponse(
    @SerializedName("folio") val folio: String,
    @SerializedName("status") val status: String,
    //@SerializedName("createdAt") val createdAt: String
)

interface ReportsApi {
    @GET("reports/{folio}")
    suspend fun getReport(@Path("folio") folio: String): ReportResponse
}