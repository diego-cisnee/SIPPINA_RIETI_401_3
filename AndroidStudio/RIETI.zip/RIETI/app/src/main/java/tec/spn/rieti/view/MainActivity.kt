package tec.spn.rieti.view

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

object Routes {
    const val MAIN = "main"
    const val HELP = "help"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                val navController = rememberNavController()

                NavHost(
                    navController = navController,
                    startDestination = Routes.MAIN
                ) {
                    composable(Routes.MAIN) {
                        MainScreen(
                            onHelp = { navController.navigate(Routes.HELP) },
                            onNewReport = { /* TODO */ },
                            onTracking = { /* TODO */ },
                            onStatistics = { /* TODO */ },
                            onMore = { /* TODO */ }
                        )
                    }
                    composable(Routes.HELP) {
                        HelpScreen(onBack = { navController.popBackStack() })
                    }
                }
            }
        }
    }
}

