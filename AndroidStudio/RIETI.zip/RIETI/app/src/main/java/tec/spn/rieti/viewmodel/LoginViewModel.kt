package tec.spn.rieti.viewmodel

class LoginViewModel {
}